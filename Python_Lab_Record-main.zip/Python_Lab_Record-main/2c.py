word=input("Enter any word")
list_1=[i for i in word if i in ('a','e','i','o','u','A','E','I','O','U')]
print("List of vowels separated from a given word is : ",list_1)