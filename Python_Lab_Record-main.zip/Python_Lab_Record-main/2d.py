word=input("Enter any word")
list2=[ord(x) for x in word]
print("The ordinal format of given word is : ",list2)