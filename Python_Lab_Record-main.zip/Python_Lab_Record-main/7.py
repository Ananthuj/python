n=input("Enter colors")
list_1=list(map(str,n.split(',')))

print(list_1[0])
print(list_1[-1])