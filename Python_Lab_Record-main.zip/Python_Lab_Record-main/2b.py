n=int(input("Enter range:"))
lst=[i**2 for i in range(1,n+1)]
print("Square of ",n," numbers in a list using list comprehension: ",lst)