list_1=['andrew','arun','athullya','athira','anand','ammu','asiya','anju']
total=0
for i in list_1:
    total+=i.count('a')
print(total)