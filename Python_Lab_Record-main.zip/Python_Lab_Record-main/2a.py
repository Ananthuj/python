lst_1=[-100,-23,98,63,0,-32,10]
print("The given list is : ",lst_1)
lst_2=[i for i in lst_1 if i>=0]
print("Positive numbers from given list of integers using list comprehension:",lst_2)